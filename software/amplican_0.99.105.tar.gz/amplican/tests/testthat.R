library(testthat)
library(amplican)

test_check("amplican")
